import { useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import usePageTitle from "../hooks/usePageTitle.js";
import { landing, person } from "../data/birthday.js";

export default function Landing() {
  usePageTitle();
  const navigate = useNavigate();

  const enter = useCallback(() => navigate("/home", { replace: true }), [navigate]);

  useEffect(() => {
    const seconds = Number(landing.autoEnterSeconds);
    if (!(seconds > 0)) return undefined;
    const timer = window.setTimeout(enter, seconds * 1000);
    return () => window.clearTimeout(timer);
  }, [enter]);

  useEffect(() => {
    const onKeyDown = (event) => {
      if (event.key === "Enter") enter();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [enter]);

  const onFrameLoad = (event) => {
    let doc = null;
    try {
      doc = event.currentTarget.contentDocument;
    } catch {
      doc = null;
    }
    if (!doc) return;
    doc.addEventListener("click", enter);
    doc.addEventListener("keydown", (e) => {
      if (e.key === "Enter") enter();
    });
  };

  return (
    <div className="cake-landing">
      <iframe
        className="cake-landing__frame"
        src="/cake/index.html"
        title={`Kue ulang tahun untuk ${person.name}`}
        onLoad={onFrameLoad}
      />
    </div>
  );
}
